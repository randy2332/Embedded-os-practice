#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define PORT 4444
#define MAX_CONNECTIONS 5
#define MAX_BUFFER_SIZE 256

int total_cookie = 0;
int total_cake =0;
int total_tea =0;
int total_boba =0;
int total_fried_rice =0;
int total_egg_drop_soup =0;
int distance =0;

void handle_error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

// Function to handle "shop list" request
void handle_shop_list(int client_socket) {
    const char *response = "Dessert shop:3km\n- cookie:$60|cake:$80\nBeverage shop:5km\n- tea:$40|boba:$70\nDiner:8km\n- fried-rice:$120|Egg-drop-soup:$50\n";
    send(client_socket, response, strlen(response), 0);
}

void handleclient(int client_socket);

void initial_item_num(void);

void update_item_count(const char *item, int quantity);

char* determine_restaurant(const char *item);

int compute_price(char * restaurant);

void sendtoclient(char *restaurant,int client_socket);
int main(int argc, char *argv[]) {

   
    if (argc!= 2){
    	fprintf(stderr,"usage : %s <port>\n",argv[0]);
    	exit(EXIT_FAILURE);
    }
    
    int server_fd, connfd;
    struct sockaddr_in addr_cln;
    socklen_t sLen = sizeof(addr_cln);

    //create socket 
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == -1) { 
        handle_error("fail to create socket");
    }

    //allow server在結束後立即重新綁定到相同的port上，而無需等待系統釋放port
    int yes = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes)) < 0) {
        handle_error("fail to setsockopt");
    }

    int port = atoi(argv[1]);
    // set the server info
    struct sockaddr_in serv_addr = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = INADDR_ANY,
        .sin_port = htons(port)
    };
    // bind
    if (bind(server_fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        handle_error("fail to bind");
    }
    //listen
    if (listen(server_fd, 10) < 0) {
        handle_error("fail to listen");
    }
    printf("Server listening on port %d...\n",port);
    while (1) {
        // Accept a new connection
        connfd = accept(server_fd, (struct sockaddr *)&addr_cln, &sLen);
        if (connfd < 0) {
            perror("fail to accept from client");
            continue;
        }
	printf("client connected\n");
	
	handleclient(connfd);
     	close (connfd);
     	printf("client unconnected\n");
       
    }

    // Close the socket
    close(server_fd);

    return 0;
}

void handleclient(int client_socket) {
    char buffer[MAX_BUFFER_SIZE] = {0};
    char order_buffer[MAX_BUFFER_SIZE] = {0}; // 用於保存客戶端的訂單信息
    char restaurant[MAX_BUFFER_SIZE] = {0}; // 用於保存當前訂單的餐廳名稱
    initial_item_num();
    int firstorder=1; 
    
    while (1) {
        read(client_socket, buffer, sizeof(buffer));
        if (strncmp(buffer, "order", 5) == 0) {
            // Parse the order string to extract item and quantity
            char item[MAX_BUFFER_SIZE] = {0};
            int quantity = 0;
            sscanf(buffer, "order %s %d", item, &quantity);
           
            // Determine the restaurant based on the first order
            if (firstorder == 1) {
                strcpy(restaurant, determine_restaurant(item));
                firstorder = 0;
            }
           
            update_item_count(item, quantity);
            
            
            // Print the item and quantity
            printf("Received order: Item: %s, Quantity: %d\n", item, quantity);
            
         
            
            //send meals that is already reserve
            sendtoclient(restaurant,client_socket);
            //const char *response = "Order received\n";
            //send(client_socket, response, MAX_BUFFER_SIZE, 0);
        } else if (strcmp(buffer, "shop list") == 0) {
            // Handle "shop list" request
            handle_shop_list(client_socket);
        } else if (strncmp(buffer, "confirm", 7) == 0){
            if (firstorder ==1){
            	const char *response = "Please order some meals\n";
            	send(client_socket,response, MAX_BUFFER_SIZE, 0);
            }
            else{
               
                const char *wait_message = "Please wait a few minutes...\n";
        	send(client_socket, wait_message, MAX_BUFFER_SIZE, 0);
		sleep(distance);
            
            	 // Update price and send it back to the client
		int total_price = compute_price(restaurant);
		
		printf("total price %d\n", total_price);
		// should send message
		//send(client_socket, &total_price,MAX_BUFFER_SIZE , 0);
		
		char delivery_message[MAX_BUFFER_SIZE];
        	snprintf(delivery_message, sizeof(delivery_message), "Delivery has arrived and you need to pay %d$\n", total_price);
        	send(client_socket, delivery_message, MAX_BUFFER_SIZE, 0);
        	
        	
        	return ;
            }
        } else if(strncmp(buffer, "cancel", 6) == 0){
            return ;
        }
        else{
            // Send a generic response for unknown requests
            const char *response = "Unknown request\n";
            send(client_socket, response, MAX_BUFFER_SIZE, 0);
        }
    }
}


void sendtoclient(char *restaurant,int client_socket) {
    char message[MAX_BUFFER_SIZE] = {0}; // Initialize the message buffer
    int has_reserved_items = 0; // Flag to track if there are reserved items
    
    // Check if there are reserved items based on the restaurant
    if (strcmp(restaurant, "Dessert shop") == 0) {
        if (total_cookie > 0) {
            snprintf(message + strlen(message), sizeof(message) - strlen(message), "cookie %d", total_cookie);
            has_reserved_items = 1; // Set flag to indicate there are reserved items
        }
        if (total_cake > 0) {
            if (has_reserved_items) {
                snprintf(message + strlen(message), sizeof(message) - strlen(message), "|"); // Add separator if needed
            }
            snprintf(message + strlen(message), sizeof(message) - strlen(message), "cake %d", total_cake);
            has_reserved_items = 1; // Set flag to indicate there are reserved items
        }
    } else if (strcmp(restaurant, "Beverage shop") == 0) {
        
        if (total_tea > 0) {
            snprintf(message + strlen(message), sizeof(message) - strlen(message), "tea %d", total_tea);
            has_reserved_items = 1; // Set flag to indicate there are reserved items
        }
        if (total_boba > 0) {
            if (has_reserved_items) {
                snprintf(message + strlen(message), sizeof(message) - strlen(message), "|"); // Add separator if needed
            }
            snprintf(message + strlen(message), sizeof(message) - strlen(message), "boba %d", total_boba);
            has_reserved_items = 1; // Set flag to indicate there are reserved items
        }
    } else if (strcmp(restaurant, "Diner") == 0) {
  	if (total_fried_rice > 0) {
            snprintf(message + strlen(message), sizeof(message) - strlen(message), "fried-rice %d", total_fried_rice);
            has_reserved_items = 1; // Set flag to indicate there are reserved items
        }
        if (total_egg_drop_soup > 0) {
            if (has_reserved_items) {
                snprintf(message + strlen(message), sizeof(message) - strlen(message), "|"); // Add separator if needed
            }
            snprintf(message + strlen(message), sizeof(message) - strlen(message), "Egg-drop-soup %d", total_egg_drop_soup );
            has_reserved_items = 1; // Set flag to indicate there are reserved items
        }
    }

    // If there are reserved items, send the message to the client
    if (has_reserved_items) {
    	strcat(message, "\n"); // Add newline character
        send(client_socket, message, MAX_BUFFER_SIZE, 0);
    }
}


int compute_price(char * restaurant){
    int price =0 ;
    if (strcmp(restaurant, "Dessert shop") == 0){
        price = total_cookie*60 +total_cake*80;
    }
    else if (strcmp(restaurant, "Beverage shop") == 0){
    	price = total_tea*40 +total_boba*70;
    }
    else if (strcmp(restaurant, "Diner") == 0){
    	price = total_fried_rice*120 +total_egg_drop_soup*50;
    }
    return price;
}

char* determine_restaurant(const char *item) {
    static char restaurant[MAX_BUFFER_SIZE] = {0}; // Declare static to preserve its value across function calls
    
    if (strcmp(item, "cookie") == 0 || strcmp(item, "cake") == 0) {
        // The restaurant is Dessert shop
        strcpy(restaurant, "Dessert shop");
        distance = 3;
    } else if (strcmp(item, "tea") == 0 || strcmp(item, "boba") == 0) {
        // The restaurant is Beverage shop
        strcpy(restaurant, "Beverage shop");
        distance = 5;
    } else if (strcmp(item, "fried-rice") == 0 || strcmp(item, "Egg-drop-soup") == 0) {
        // The restaurant is Diner
        strcpy(restaurant, "Diner");
        distance =8;
    } else {
        printf("No such item or restaurant\n");
        strcpy(restaurant, "Unknown");
    }
    
    return restaurant;
}


void update_item_count(const char *item, int quantity) {
    if (strcmp(item, "cookie") == 0) {
        total_cookie += quantity;
    } else if (strcmp(item, "cake") == 0) {
        total_cake += quantity;
    } else if (strcmp(item, "tea") == 0) {
        total_tea += quantity;
    } else if (strcmp(item, "boba") == 0) {
        total_boba += quantity;
    } else if (strcmp(item, "fried-rice") == 0) {
        total_fried_rice += quantity;
    } else if (strcmp(item, "Egg-drop-soup") == 0) {
        total_egg_drop_soup += quantity;
    }
}



void initial_item_num(void){
    total_cookie = 0;
    total_cake =0;
    total_tea =0;
    total_boba =0;
    total_fried_rice =0;
    total_egg_drop_soup =0;
    distance = 0; 
}

